This is a list of all the contributors to OpenImageIO, sorted alphabetically
by first name.

If you know of somebody that I missed or have corrections, please email:
lg@openimageio.org

* Aaron Colwell
* Adam Mains
* Akihiro Yamasaki
* Alan Jones
* Alejandro Conty
* Alex Guirre
* Alex Hughes
* Alex Schworer
* Alexander Kuleshov
* Alexander Murashko
* Alexandre Gauthier
* Alexis Oblet
* Alexy Pawlow
* Alister Chowdhury
* Aman Shah
* Ananth Garre
* Anders Langlands
* Andy Chan
* AngryLoki
* Angus Davis
* Anthony Nemoff
* Anton Dukhovnikov
* Aras Pranckevičius
* Arkady Shapkin
* Aura Munoz
* Basileios Anastasatos
* Bastien Montagne
* Ben De Luca
* Benjamin Buch
* Bernhard Rosenkraenzer
* Biswapriyo Nath
* Blair Tennessy
* Blazej Floch
* Brad Smith
* Brecht Van Lommel
* Brent Davis
* Brian Hall
* Brice Gros
* Calvin Schaul
* Carl Rand
* Cassian Andrei
* Chad Dombrova
* Chaitanya Sharma
* Changlin Hsieh
* Chris Crosetto
* Chris Foster
* Chris Hellmuth
* Chris Kulla
* Chris Whalen
* Christoph Willing
* Cliff Stein
* Clément Champetier
* D-Spirits
* Dalai Felinto
* Dan Wexler
* Daniel Dresser
* Daniel Flehner Heen
* Daniel Wyatt
* Danny Greenstein
* David Aguilar
* David Gordon
* Deepak Gopinath
* Dennis Schridde
* Dieter De Baets
* Dinko Galetik
* Dominik Bartkiewicz
* Dominik Wójt
* Duncan Chan
* Dustin Rodrigues
* Edgar Velazquez-Armendariz
* Eloi Du Bois
* Elvic Liang
* Emil Dohne
* Fabien Castan
* Fabien Servant
* Fredrik Averpil
* Frédéric Devernay
* Gaurav Bansal
* Gerdya
* Ghislain Antony Vaillant
* Gonzalo Garramuño
* Gregor Mueckl
* Grégoire De Lillo
* Guillaume Chatelet
* Hanspeter Niederstrasser
* Harry Mallon
* Heiko Becker
* Henri Fousse
* Hugh Macdonald
* Imarz
* Irena Damsky
* Ismael Cortes
* Jan Hettenkofer
* Jan Honsbrok
* Jason Baumeister
* Jens Lindgren
* Jep Hill
* Jeph Alapat
* Jeremy Retailleau
* Jeremy Rose
* Jeremy Selan
* Jesse Yurkovich
* Jim Hourihan
* Johannes Unterguggenberger
* John Burnett
* John Fea
* John Haddon
* Jonathan Hearn
* Jonathan Scruggs
* Joris Nijs
* Joseph Goldstone
* Julien Enche
* Justin Israel
* Justina Mikonyte
* Kaarrot
* Kazuki Takahashi
* Kevin Brightwell
* Kimball Thurston
* Konrad Kleine
* Krzysztof Blicharski
* Larry Gritz (project leader)
* LazyDodo
* Leonid Onokhov
* Leszek Godlewski
* Loïc Vital
* Lucas Panian
* Lucille Caillaud
* Lukas Schrangl
* Lukasz Maliszewski
* Luke Emrose
* M Joonas Pihlaja
* Malcolm Humphreys
* Manuel Gamito
* Manuel Leonhardt
* Marcos Fajardo
* Marie Fetiveau
* Mariusz Szczepanczyk
* Mark Boorer
* Mark Visser
* Massimo Paladin
* Matteo F. Vescovi
* Matthew E. Levine
* Max Liani
* Merwan Achibet
* Michael Cho
* Michael Oliver
* Michel Lerenard
* Michel Normand
* Mikael Sundell
* Mike Root
* Morteza Ramezanali
* Nandan Dubey
* Nathan Rusch
* Nicholas Yue
* Nick Black
* Nicolas Burtnyk
* Nicolas Vivien
* Nixon Kwok
* Noah Rahm (designer of our logo!)
* Northon Patrick
* Nuno Cardoso
* Ole Gulbrandsen
* Ott Tinn
* Pascal Lecocq
* Patrick Hodoul
* Patrick Piché
* Paul Melis
* Paul Molodowitch
* Pavel Karneliuk
* Pete Larabell
* Peter Kovář
* Philip Nemec
* Pino Toscano
* Povilas Kanapickas
* Puneet Jain
* Radu Arjocu
* Ramon Montoya
* Ray Molenkamp
* Rémi Achard
* Richard Shaw
* Robert Matusewicz
* Roeland Schoukens
* Roman Zulak
* Rui Li
* Russell Greene
* Ryen
* Saket Jalan
* Sam Richards
* Samuel Nicholas
* Scott Wilson
* Sebastian Elsner
* SebTV
* Seifeddine Dridi
* Sergey Sharybin
* Sergio Rojas
* Shane Ambler
* Simon Boorer
* Solomon Boulos
* SRHMorris
* Stefan Bruens
* Stefan Stavrev
* Thiago Ize
* Thomas Dinges
* Thomas Mansencal
* Till Dechent
* Tim D. Smith
* Tim Grant
* Tom Knowles
* Troy James Sobotka
* Vic P
* Vinod Khare
* Vishal Agrawal
* Vitor Franchi
* Vlad (Kuzmin) Erium
* Wayne Arnold
* Will Rosecrans
* William Krick
* Wormszer
* xiaoxiaoafeifei
* Xo Wang
* Yang Yang
* Yann Lanthony
* Ziggy Cross
* zomgrolf
